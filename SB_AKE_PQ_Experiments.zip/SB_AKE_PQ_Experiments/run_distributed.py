"""Matched separate-process experiments, plus explicit delayed-delivery cases."""
import argparse
import csv
import hashlib
import json
import platform
import time
from pathlib import Path
import cryptography
from distributed import DistributedRun
from run_experiments import CANDIDATES, NAMES, event, scenario

ALL_NAMES = NAMES + ("delayed_update", "delayed_ack", "delayed_update_revocation")


def schedule(name, seed):
    if name in NAMES: return scenario(name, seed)
    steps = [event(0, "establish"), event(1, "service"), event(2, "change")]
    if name == "delayed_update":
        steps += [event(3, "deliver", kind="UPD", delay=True), event(4, "service"),
                  event(5, "deliver", kind="UPD"), event(6, "deliver", kind="ACK")]
    elif name == "delayed_ack":
        steps += [event(3, "deliver", kind="UPD"), event(4, "deliver", kind="ACK", delay=True),
                  event(5, "service"), event(6, "deliver", kind="ACK")]
    elif name == "delayed_update_revocation":
        steps += [event(3, "deliver", kind="UPD", delay=True), event(4, "revoke"),
                  event(5, "deliver", kind="UPD"), event(6, "deliver", kind="ACK")]
    else: raise ValueError(name)
    return steps+[event(7, "service"), event(8, "service", slice="slice-B")]


def normalized_trace(trace):
    return [{k: v for k, v in entry.items() if k not in ("old_pid", "new_pid")} for entry in trace]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=10)
    ap.add_argument("--out", type=Path, default=Path("distributed_results"))
    ap.add_argument("--wall-delay-ms", type=float, default=0,
                    help="additional sleep per forwarded lifecycle packet; diagnostic only")
    args = ap.parse_args()
    if args.seeds < 1 or args.wall_delay_ms < 0: ap.error("invalid seed count or delay")
    args.out.mkdir(parents=True, exist_ok=True)
    rows, workloads, mismatches, failures, identity = [], [], [], [], []
    start = time.perf_counter()
    for name in ALL_NAMES:
        for seed in range(args.seeds):
            steps = schedule(name, seed)
            sha = hashlib.sha256(json.dumps(steps, sort_keys=True).encode()).hexdigest()
            workloads.append({"scenario": name, "seed": seed, "schedule_sha256": sha, "events": steps})
            paired, traces = {}, {}
            for candidate in CANDIDATES:
                run = DistributedRun(candidate, seed, wall_delay_ms=args.wall_delay_ms)
                try:
                    for e in steps: run.act(e)
                    result = run.result(); paired[candidate] = result
                    traces[candidate] = normalized_trace(run.trace)
                    rows.append({"scenario": name, "seed": seed, "candidate": candidate, "schedule_sha256": sha, **result})
                    identity.append({"scenario": name, "seed": seed, "candidate": candidate,
                                     "processes": run.pid_history})
                    if candidate != "generic_minimal":
                        for k in ("duplicate_installations", "obsolete_policy_acceptances",
                                  "revoked_service_acceptances", "acceptances_before_exact_ack"):
                            if result[k]: failures.append([name, seed, candidate, k])
                    if seed == 0:
                        (args.out/f"trace_{name}_{candidate}.json").write_text(json.dumps(run.trace, indent=2))
                        (args.out/f"timings_{name}_{candidate}.json").write_text(json.dumps(run.timings, indent=2))
                finally: run.close()
            if paired["sbake"] != paired["generic_guarded"] or traces["sbake"] != traces["generic_guarded"]:
                mismatches.append([name, seed])
        print(f"Completed {name}: {args.seeds * 3} candidate runs", flush=True)
    with (args.out/"runs.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    numeric = [k for k in rows[0] if k not in ("scenario", "seed", "candidate", "schedule_sha256")]
    aggregated = []
    for name in ALL_NAMES:
        for candidate in CANDIDATES:
            selected = [r for r in rows if r["scenario"] == name and r["candidate"] == candidate]
            aggregated.append({"scenario": name, "candidate": candidate, "runs": len(selected),
                               **{k: sum(r[k] for r in selected)/len(selected) for k in numeric}})
    with (args.out/"summary.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(aggregated[0])); w.writeheader(); w.writerows(aggregated)
    (args.out/"schedules.json").write_text(json.dumps(workloads, indent=2))
    (args.out/"process_identity.json").write_text(json.dumps(identity, indent=2))
    metadata = {"scope": "separate endpoint and SF processes; trusted controller/fault relay; loopback TCP",
                "python": platform.python_version(), "cryptography": cryptography.__version__,
                "seeds": args.seeds, "scenarios": len(ALL_NAMES), "candidate_runs": len(rows),
                "guarded_safety_failures": failures, "guarded_pair_mismatches": mismatches,
                "wall_delay_ms": args.wall_delay_ms, "delay_ticks": 2,
                "elapsed_suite_seconds": time.perf_counter()-start,
                "handshake_measured": False, "hardware_measured": False,
                "time_unit": "scripted event ticks; RPC diagnostics use nanoseconds"}
    (args.out/"run_metadata.json").write_text(json.dumps(metadata, indent=2))
    print(json.dumps(metadata, indent=2))
    if failures or mismatches: raise SystemExit(1)


if __name__ == "__main__": main()
