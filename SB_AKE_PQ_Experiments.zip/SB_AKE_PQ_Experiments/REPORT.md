# Real stored-key handshake and recovery results

Executed software: Python 3.12.14, cryptography 50.0.2, pqcrypto 0.4.0, OpenSSL 4.0.3 29 Sep 2026. Platform: Linux-6.18.44-x86_64-with-glibc2.39.

All **54 regression tests passed**. The final measurement run completed **60 fresh-root handshake measurements** (30 per profile) and **390 matched lifecycle executions** (13 scenarios × five schedule seeds × three candidates × two profiles). No accepted-root fixtures were used in this run. Both guarded candidates had no monitored lifecycle violations and matching semantic traces and lifecycle metric vectors.

## Handshake measurements

Observed host-loopback measurements, not ESP32-C6 predictions. Each profile used already running workers and retained signing credentials; the first exchange establishes an association and the next 29 replace it with fresh ephemeral KEM material. The values describe this execution only.

| Profile | Mean (ms) | Median (ms) | Observed p95 (ms) | Mean handler subset (ms) | Mean asymmetric-crypto subset (ms) | Binary protocol bytes |
|---|---:|---:|---:|---:|---:|---:|
| P1 | 4.637 | 4.119 | 6.987 | 3.204 | 2.584 | 10820 |
| P2 | 5.526 | 4.830 | 10.184 | 4.108 | 3.385 | 15940 |

P1 uses ML-KEM-512/ML-DSA-44; P2 uses ML-KEM-768/ML-DSA-65. Root derivation uses real session KEM secrets, exact-wire transcript binding and HKDF. M1/M2 encrypt actual signed padded payloads under AES-256-GCM; M3/M4 execute mutual key confirmation. The relay never receives root or shared-secret values.

Handler and asymmetric-operation durations are nested subsets of elapsed handshake latency and must not be added to it. Elapsed handshake latency includes local IPC and serialization; provisioning, credential loading and worker startup are excluded. Binary sizes include the experimental fixed padding and length prefixes; they exclude base64 control envelopes and TCP/IP headers. The different sizes from the manuscript lower bounds are expected and must be reported as a distinct implemented wire profile.

## Recovery observations

Table values are medians over five SB-AKE executions per profile. Recovery starts immediately before the scheduled fault injection and ends at the first subsequent successful slice-A service probe. These are scripted recovery observations, not autonomous timer/backoff latency. Restart rows include killing and creating a worker and reloading credentials.

| Scenario | P1 median (ms) | P2 median (ms) | Additional handshake bytes P1 / P2 | Additional lifecycle bytes |
|---|---:|---:|---:|---:|
| lost_ack | 1.322 | 1.094 | 0 / 0 | 473 |
| endpoint_restart | 67.737 | 65.454 | 10820 / 15940 | 0 |
| sf_restart | 70.804 | 62.978 | 10820 / 15940 | 0 |
| pending_policy_change | 3.710 | 5.636 | 10820 / 15940 | 0 |
| permanent_ack_loss | 5.390 | 6.761 | 10820 / 15940 | 1419 |

Incremental bytes begin at injection: packets already sent before the fault are excluded. A lost ACK can recover through one exact cached update/ACK retry (473 bytes here), whereas worker restart or a second pending policy change requires another full real handshake. Permanent ACK loss performs three scripted retries before prescribed reauthorization. The actual OS restart cost dominates the restart observations on this host.

For the minimal diagnostic comparator, first accepted traffic can precede exact ACK validation and does not constitute secure recovery. Its raw recovery rows are retained for transparency but omitted from the secure recovery table above. The equally guarded generic hierarchy uses the same lifecycle engine and handshake; these experiments establish executable consistency, not a unique SB-AKE performance gain.

## Cached handshake-loss controls

A lost M2 triggers exact M1/M2 retransmission; a lost M4 triggers cached M3/M4 retransmission. Both complete using the same nine asymmetric operations as the no-loss exchange: no second signature or fresh encapsulation is performed for an exact retry. The prescribed retry is immediate and does not charge a real timeout wait. Raw durations and bytes are in handshake_costs.csv.

## Security regression coverage

Tests cover both parameter profiles, independent matching roots and exports, fresh-run randomness, all four cached handshake messages, modified concealment KEM ciphertext, modified request/grant ciphertext, wrong confirmation tags, wrong pinned signing keys, profile mismatch, stale response transcripts, policy changes during the handshake, revoked-slice grant exclusion, malformed padding, and HKDF-Expand agreement with the library API. ML-KEM-768 was additionally checked for two-way interoperability between pqcrypto and cryptography/OpenSSL. Late malformed confirmations preserve an accepted root; duplicate accepted handshake messages preserve the traffic replay guard. Existing lifecycle, socket/restart and tampering tests remain included.

## Manuscript-ready statement

> A stored-credential software prototype executed the concealed ML-KEM/ML-DSA handshake between separate endpoint and serving-function processes. The peers derived transcript-bound roots locally and completed mutual key confirmation before application-key use. Thirty fresh-root exchanges per parameter profile supplied host-loopback timing and encoded-message measurements. Matched fault schedules then exercised acknowledged updates, duplication, policy replacement, service-side revocation and process restart using real reauthorization exchanges. Across 390 candidate executions, the two equally guarded lifecycle profiles reported no monitored violations and matching semantic behavior. These measurements apply to the implemented software/wire profile; embedded performance, PUF feasibility, arbitrary concurrent traces and complete computational security remain outside the evidence.

## Scope and reproducibility

Credentials are freshly provisioned offline, stored as private lab files, and loaded once per worker startup. No PUF, enrollment-manifest path, secure element, remote policy service, autonomous timeout scheduler, full root-expiry model or unrestricted session concurrency is included. The execution is serialized by a trusted local controller. Only one accepted association and one pending handshake per peer are supported.

Host measurements must not replace ESP32-C6 timings without relabeling the platform, profile and accounting boundary. Mean/p95 estimates from 30 trials are descriptive; no device-tail distribution or security probability is inferred. Timing files and fresh cryptographic transcript hashes will vary on reproduction. Source profiles and schedule IDs are pinned, and expected safety counts should reproduce.

Reproduction: follow README.md and run run_pq_experiments.py with --profiles P1 P2 --trials 30 --seeds 5. Preserve the newly produced output folder and test log for your own machine.
