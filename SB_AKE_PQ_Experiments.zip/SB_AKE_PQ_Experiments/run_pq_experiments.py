"""Measure real stored-key PQ handshakes and matched lifecycle recovery."""
import argparse
import csv
import hashlib
import importlib.metadata
import json
import platform
import statistics
import tempfile
import time
from pathlib import Path
import cryptography
from cryptography.hazmat.backends.openssl.backend import backend
from distributed import DistributedRun
from pq_handshake import provision
from run_distributed import ALL_NAMES, schedule
from run_experiments import CANDIDATES


def write_csv(path, rows):
    if not rows: return
    fields = list(dict.fromkeys(k for r in rows for k in r))
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(rows)


def semantic_trace(trace):
    exclude = {"old_pid", "new_pid", "sid", "digest", "message_sha256"}
    return [{k:v for k,v in row.items() if k not in exclude} for row in trace]


def percent(values, q):
    values = sorted(values); index = (len(values)-1)*q
    lo = int(index); hi = min(lo+1,len(values)-1)
    return values[lo]+(values[hi]-values[lo])*(index-lo)


def fault_start(name, e):
    return ((name in ("endpoint_restart","sf_restart") and e["op"] == "restart")
            or (name in ("lost_ack","permanent_ack_loss") and e.get("drop"))
            or (name == "pending_policy_change" and e["op"] == "change" and e["tick"] == 4)
            or (name in ("delayed_ack","delayed_update") and e.get("delay")))


def lifecycle_bytes(run):
    return sum(run.saved_metrics[r]["encoded_bytes_sent"]+run.metrics.get(r,{}).get("encoded_bytes_sent",0)
               for r in ("endpoint","sf"))


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--profiles", nargs="+", choices=["P1","P2"],default=["P1","P2"])
    ap.add_argument("--trials",type=int,default=30)
    ap.add_argument("--seeds",type=int,default=5)
    ap.add_argument("--out",type=Path,default=Path("pq_results"))
    ap.add_argument("--wall-delay-ms",type=float,default=0)
    args=ap.parse_args()
    if args.trials<1 or args.seeds<1 or args.wall_delay_ms<0: ap.error("invalid counts or delay")
    args.out.mkdir(parents=True,exist_ok=True)
    costs, lifecycle, recovery, workloads, failures, mismatches, processes = [],[],[],[],[],[],[]
    t0=time.perf_counter()
    with tempfile.TemporaryDirectory(prefix="sbake_private_credentials_") as credentials:
        for profile in args.profiles:
            provision(credentials,profile)
            # One pair per profile: first handshake and repeated fresh-root runs.
            run=DistributedRun("sbake",0,credentials=credentials,profile=profile,wall_delay_ms=args.wall_delay_ms)
            try:
                for trial in range(args.trials):
                    run.establish()
                    m=run.handshake_measurements[-1]
                    costs.append({"profile":profile,"context":"handshake_benchmark","trial":trial,
                                  **{k:v for k,v in m.items() if k!="messages"}})
                    raw=run.call("endpoint","probe",slice="slice-A",request_id=trial+1)
                    if not run.call("sf","service",slice="slice-A",raw=raw): raise RuntimeError("no service after handshake")
                (args.out/f"crypto_operations_{profile}.json").write_text(json.dumps(run.crypto_operations,indent=2))
            finally:run.close()
            print(f"{profile}: measured {args.trials} fresh-root handshakes",flush=True)
            for name in ALL_NAMES:
                for seed in range(args.seeds):
                    events=schedule(name,seed)
                    sha=hashlib.sha256(json.dumps(events,sort_keys=True).encode()).hexdigest()
                    workloads.append({"profile":profile,"scenario":name,"seed":seed,"sha256":sha,"events":events})
                    paired,traces={},{}
                    for candidate in CANDIDATES:
                        run=DistributedRun(candidate,seed,credentials=credentials,profile=profile,wall_delay_ms=args.wall_delay_ms)
                        fault_time=None; restored=False; bytes_before=0; hs_bytes_before=0
                        try:
                            for e in events:
                                if fault_time is None and fault_start(name,e):
                                    fault_time=time.perf_counter_ns()
                                    bytes_before=lifecycle_bytes(run)
                                    hs_bytes_before=sum(m["protocol_bytes_sent"] for m in run.handshake_measurements)
                                run.act(e)
                                if (fault_time is not None and not restored and e["op"]=="service"
                                    and e.get("slice","slice-A")=="slice-A" and run.last["sf"]["output"] is True):
                                    restored=True
                                    after=lifecycle_bytes(run)
                                    recovery.append({"profile":profile,"scenario":name,"seed":seed,"candidate":candidate,
                                        "restored":True,"elapsed_from_injection_ns":time.perf_counter_ns()-fault_time,
                                        "incremental_lifecycle_bytes":after-bytes_before,
                                        "incremental_handshake_bytes":sum(m["protocol_bytes_sent"] for m in run.handshake_measurements)-hs_bytes_before})
                            result=run.result();paired[candidate]=result;traces[candidate]=semantic_trace(run.trace)
                            lifecycle.append({"profile":profile,"scenario":name,"seed":seed,"candidate":candidate,"schedule_sha256":sha,**result})
                            if fault_time is not None and not restored:
                                recovery.append({"profile":profile,"scenario":name,"seed":seed,"candidate":candidate,"restored":False})
                            for m in run.handshake_measurements:
                                costs.append({"profile":profile,"context":"lifecycle","scenario":name,"seed":seed,
                                              "candidate":candidate,**{k:v for k,v in m.items() if k!="messages"}})
                            processes.append({"profile":profile,"scenario":name,"seed":seed,"candidate":candidate,"workers":run.pid_history})
                            if candidate!="generic_minimal":
                                for k in ("duplicate_installations","obsolete_policy_acceptances","revoked_service_acceptances","acceptances_before_exact_ack"):
                                    if result[k]:failures.append([profile,name,seed,candidate,k])
                            if result["accepted_root_fixtures"]:raise RuntimeError("fixture used in PQ mode")
                            if seed==0:
                                (args.out/f"trace_{profile}_{name}_{candidate}.json").write_text(json.dumps(run.trace,indent=2))
                        finally:run.close()
                    if paired["sbake"]!=paired["generic_guarded"] or traces["sbake"]!=traces["generic_guarded"]:
                        mismatches.append([profile,name,seed])
                print(f"{profile} {name}: {args.seeds*3} matched candidate runs",flush=True)
            # Immediate cached handshake retry microbenchmarks, not timeout latency.
            for loss in ("M2","M4"):
                run=DistributedRun("sbake",0,credentials=credentials,profile=profile,wall_delay_ms=args.wall_delay_ms)
                try:
                    run.establish(drop_once=loss)
                    costs.append({"profile":profile,"context":"handshake_loss_control",
                                  **{k:v for k,v in run.handshake_measurements[-1].items() if k!="messages"}})
                finally:run.close()
    write_csv(args.out/"handshake_costs.csv",costs)
    write_csv(args.out/"lifecycle_runs.csv",lifecycle)
    write_csv(args.out/"recovery_costs.csv",recovery)
    summary=[]
    for profile in args.profiles:
        selected=[r for r in costs if r["profile"]==profile and r["context"]=="handshake_benchmark"]
        values=[r["elapsed_ns"]/1e6 for r in selected]
        summary.append({"profile":profile,"trials":len(values),"mean_ms":statistics.mean(values),
                        "median_ms":statistics.median(values),"p95_ms":percent(values,.95),
                        "sd_ms":statistics.stdev(values) if len(values)>1 else 0,
                        "mean_handler_ms":statistics.mean(r["handler_ns"]/1e6 for r in selected),
                        "mean_crypto_ms":statistics.mean(r["crypto_ns"]/1e6 for r in selected),
                        "protocol_bytes":selected[0]["protocol_bytes_sent"]})
    write_csv(args.out/"handshake_summary.csv",summary)
    (args.out/"schedules.json").write_text(json.dumps(workloads,indent=2))
    (args.out/"process_identity.json").write_text(json.dumps(processes,indent=2))
    metadata={"scope":"real stored-credential ML-KEM/ML-DSA handshake plus separate-process lifecycle",
              "python":platform.python_version(),"cryptography":cryptography.__version__,
              "pqcrypto":importlib.metadata.version("pqcrypto"),"openssl":backend.openssl_version_text(),
              "platform":platform.platform(),"profiles":args.profiles,"benchmark_trials_per_profile":args.trials,
              "seeds":args.seeds,"scenarios":len(ALL_NAMES),"candidate_runs":len(lifecycle),
              "guarded_safety_failures":failures,"guarded_pair_mismatches":mismatches,
              "handshake_measured":True,"hardware_measured":False,"root_fixtures_used":False,
              "wall_delay_ms":args.wall_delay_ms,"elapsed_suite_seconds":time.perf_counter()-t0,
              "wire_profile":"LP32-json-slots-v1","puf_implemented":False,
              "recovery_timer":"scripted immediate retries, no autonomous timeout wait"}
    (args.out/"run_metadata.json").write_text(json.dumps(metadata,indent=2))
    print(json.dumps({"metadata":metadata,"handshake_summary":summary},indent=2))
    if failures or mismatches:raise SystemExit(1)


if __name__=="__main__":main()
