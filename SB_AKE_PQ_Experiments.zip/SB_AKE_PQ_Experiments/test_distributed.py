import unittest
import base64
from lifecycle import parse, encode
from distributed import DistributedRun
from run_distributed import schedule


class DistributedTests(unittest.TestCase):
    def run_case(self, name):
        run = DistributedRun("sbake", 0)
        try:
            for e in schedule(name, 0): run.act(e)
            return run.result(), run.trace, run.pid_history
        finally: run.close()

    def test_distinct_processes_and_honest_commit(self):
        result, trace, pids = self.run_case("normal")
        self.assertNotEqual(pids[0]["pid"], pids[1]["pid"])
        self.assertEqual(result["committed_updates"], 1)
        self.assertEqual(result["acceptances_before_exact_ack"], 0)

    def test_lost_ack_duplicate_safe(self):
        result, _, _ = self.run_case("lost_ack")
        self.assertEqual(result["installations"], 1)
        self.assertEqual(result["committed_updates"], 1)

    def test_delayed_ack_gates_service(self):
        result, trace, _ = self.run_case("delayed_ack")
        self.assertEqual(result["authorized_service_rejections"], 1)
        self.assertTrue(any(t["event"] == "delay" for t in trace))
        self.assertEqual(result["committed_updates"], 1)

    def test_delayed_update_revocation(self):
        result, trace, _ = self.run_case("delayed_update_revocation")
        self.assertEqual(result["installations"], 1)
        self.assertEqual(result["service_accepted"], 2) # Initial A and unaffected final B.
        self.assertEqual(result["committed_updates"], 0)

    def test_restart_changes_endpoint_pid(self):
        result, trace, pids = self.run_case("endpoint_restart")
        ep = [p["pid"] for p in pids if p["role"] == "endpoint"]
        self.assertEqual(len(ep), 2); self.assertNotEqual(ep[0], ep[1])
        self.assertEqual(result["authorized_service_rejections"], 1)

    def test_sf_restart_keeps_authority_but_not_root(self):
        result, trace, pids = self.run_case("sf_restart")
        sf = [p["pid"] for p in pids if p["role"] == "sf"]
        self.assertEqual(len(sf), 2); self.assertNotEqual(sf[0], sf[1])
        self.assertEqual(result["authorized_service_rejections"], 1)

    def test_wire_tamper_is_rejected_at_endpoint(self):
        run = DistributedRun("sbake", 0)
        try:
            run.establish(); run.call("sf", "change", slice="slice-A")
            raw = base64.b64decode(run.messages[0]["raw"])
            msg = parse(raw); ct = bytearray.fromhex(msg["ct"]); ct[-1] ^= 1; msg["ct"] = ct.hex()
            run.call("endpoint", "receive", raw=base64.b64encode(encode(msg)).decode())
            self.assertEqual(run.result()["installations"], 0)
        finally: run.close()

    def test_service_probe_replay_is_rejected_at_sf(self):
        run = DistributedRun("sbake", 0)
        try:
            run.establish()
            raw = run.call("endpoint", "probe", slice="slice-A", request_id=1)
            self.assertTrue(run.call("sf", "service", slice="slice-A", raw=raw))
            self.assertFalse(run.call("sf", "service", slice="slice-A", raw=raw))
        finally: run.close()

    def test_retransmission_bytes_identical_across_sockets(self):
        run = DistributedRun("sbake", 0)
        try:
            run.establish(); run.call("sf", "change", slice="slice-A")
            first = run.messages[0]["raw"]
            run.deliver("UPD", "slice-A"); run.deliver("ACK", "slice-A", drop=True)
            run.call("sf", "retry", slice="slice-A")
            self.assertEqual(first, run.messages[-1]["raw"])
        finally: run.close()


if __name__ == "__main__": unittest.main()
