"""Stored-credential SB-AKE handshake, experimental canonical binary profile.

Equations 10--35 are instantiated with length-prefixed encodings. No PUF.
"""
import base64
import hashlib
import hmac
import json
import os
import struct
import time
from pathlib import Path
from cryptography.exceptions import InvalidSignature, InvalidTag
from cryptography.hazmat.primitives.asymmetric import mldsa
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from pqcrypto.kem import ml_kem_512, ml_kem_768
from lifecycle import Peer, SliceState, encode

CONTEXT = b"SB-AKE-v3"
ZERO_NONCE = bytes(12)
PROFILES = {"P1": (ml_kem_512, mldsa.MLDSA44PrivateKey, mldsa.MLDSA44PublicKey, 4096),
            "P2": (ml_kem_768, mldsa.MLDSA65PrivateKey, mldsa.MLDSA65PublicKey, 6144)}


def pack(*parts):
    return b"".join(struct.pack("!I", len(p))+p for p in parts)


def unpack(raw, count=None):
    if type(raw) is not bytes or len(raw) > 32768: raise ValueError("frame")
    fields, offset = [], 0
    while offset < len(raw):
        if offset+4 > len(raw): raise ValueError("truncated length")
        n = struct.unpack("!I", raw[offset:offset+4])[0]; offset += 4
        if offset+n > len(raw): raise ValueError("truncated field")
        fields.append(raw[offset:offset+n]); offset += n
    if count is not None and len(fields) != count: raise ValueError("field count")
    return fields


def pad(raw, size):
    if len(raw)+4 > size: raise ValueError("capacity")
    return struct.pack("!I", len(raw))+raw+bytes(size-len(raw)-4)


def unpad(raw, size):
    if len(raw) != size: raise ValueError("padding size")
    n = struct.unpack("!I", raw[:4])[0]
    if n > size-4 or any(raw[4+n:]): raise ValueError("padding")
    return raw[4:4+n]


def canonical_json(raw):
    def unique(pairs):
        d = {}
        for k, v in pairs:
            if k in d: raise ValueError("duplicate field")
            d[k] = v
        return d
    d = json.loads(raw, object_pairs_hook=unique)
    if encode(d) != raw: raise ValueError("noncanonical JSON")
    return d


def H(raw): return hashlib.sha256(raw).digest()
def extract(salt, secret): return hmac.digest(salt, secret, "sha256")
def expand(prk, info): return hmac.digest(prk, info+b"\x01", "sha256")
def enc64(raw): return base64.b64encode(raw).decode("ascii")
def dec64(raw): return base64.b64decode(raw, validate=True)


def provision(directory, profile):
    """Offline trusted provisioning, excluded from handshake timings."""
    path = Path(directory); path.mkdir(parents=True, exist_ok=True)
    kem, signer, _, _ = PROFILES[profile]
    ep, sf = signer.generate(), signer.generate()
    npk, nsk = kem.generate_keypair()
    epub, sfpub = ep.public_key().public_bytes_raw(), sf.public_key().public_bytes_raw()
    records = {
        "endpoint": {"signing_seed": enc64(ep.private_bytes_raw()), "peer_signing_public": enc64(sfpub),
                     "concealment_public": enc64(npk), "own_signing_public": enc64(epub)},
        "sf": {"signing_seed": enc64(sf.private_bytes_raw()), "peer_signing_public": enc64(epub),
               "concealment_private": enc64(nsk), "concealment_public": enc64(npk), "own_signing_public": enc64(sfpub)}}
    for role, fields in records.items():
        file = path/f"{profile}_{role}.json"
        fd = os.open(file, os.O_WRONLY|os.O_CREAT|os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f: json.dump({"profile": profile, **fields}, f)
        os.chmod(file, 0o600)


class PQPeer(Peer):
    def __init__(self, profile_bytes):
        super().__init__(); self.profile_bytes = profile_bytes

    def key(self, label, s, context=None):
        if self.root is None: raise ValueError("no accepted root")
        upd = expand(self.root, pack(b"update", self.profile_bytes, b"device-1", s.encode(), b"telemetry"))
        if label == "upd": return upd
        if label == "ack": return expand(upd, pack(b"ack", bytes.fromhex(self.sid)))
        if label != "traffic": raise ValueError("unknown key purpose")
        epoch, policy = context
        ctx = pack(b"device-1", s.encode(), b"telemetry", policy.encode(), epoch.to_bytes(8, "big"))
        base = expand(self.root, pack(b"slice", self.profile_bytes, ctx))
        return expand(base, pack(b"traffic", self.profile_bytes, bytes.fromhex(self.sid), ctx,
                                 b"endpoint-to-SF", b"telemetry"))


class Handshake:
    def __init__(self, role, sim, credentials, profile):
        self.role, self.sim, self.profile = role, sim, profile
        self.kem, signer, verifier, self.outer = PROFILES[profile]
        cfg = json.loads((Path(credentials)/f"{profile}_{role}.json").read_text())
        if cfg["profile"] != profile: raise ValueError("credential profile")
        self.signer = signer.from_seed_bytes(dec64(cfg["signing_seed"]))
        self.peer_verifier = verifier.from_public_bytes(dec64(cfg["peer_signing_public"]))
        self.own_public = dec64(cfg["own_signing_public"])
        if self.signer.public_key().public_bytes_raw() != self.own_public: raise ValueError("credential mismatch")
        self.npk = dec64(cfg["concealment_public"])
        self.nsk = dec64(cfg["concealment_private"]) if role == "sf" else None
        sfpk = self.own_public if role == "sf" else dec64(cfg["peer_signing_public"])
        self.sfpk_hash = H(sfpk)
        self.P = encode({"version": "SB-AKE-v3", "wire": "LP32-json-slots-v1", "profile": profile,
                         "network": "local-lab", "sf": "SF-1", "mode": "stored-key-concealed",
                         "suite": "ML-KEM-512/ML-DSA-44" if profile == "P1" else "ML-KEM-768/ML-DSA-65",
                         "capacity": 2, "inner_size": 512, "outer_size": self.outer,
                         "sf_key_id": self.sfpk_hash.hex(), "concealment_key_id": H(self.npk).hex()})
        sim.endpoint, sim.sf = PQPeer(self.P), PQPeer(self.P)
        self.phase = "IDLE"
        self.ops = []
        self.clear_transient()

    def timed(self, name, fn, *args):
        t = time.perf_counter_ns(); result = fn(*args)
        self.ops.append({"role": self.role, "operation": name, "ns": time.perf_counter_ns()-t})
        return result

    def clear_transient(self):
        self.dk = self.kpriv = self.pending_root = self.kconf = None
        self.m1 = self.m2 = self.m3 = self.m4 = None
        self.grant = self.request = None
        self.T = self.kce = None

    def abort(self, clear_peer=False):
        if clear_peer:
            (self.sim.endpoint if self.role == "endpoint" else self.sim.sf).reset()
        self.clear_transient(); self.phase = "ABORTED"

    def inner(self, entries):
        return pad(encode(entries+[None]*(2-len(entries))), 512)

    def entries(self, padded, grant=False):
        slots = canonical_json(unpad(padded, 512))
        if type(slots) is not list or len(slots) != 2: raise ValueError("slots")
        used, seen, dummy = [], set(), False
        for item in slots:
            if item is None: dummy = True; continue
            if dummy or type(item) is not dict: raise ValueError("dummy slots")
            fields = {"slice", "role", "epoch", "policy"} if grant else {"slice", "role", "minimum"}
            if set(item) != fields or item["slice"] not in ("slice-A", "slice-B") or item["role"] != "telemetry":
                raise ValueError("entry")
            if item["slice"] in seen: raise ValueError("duplicate slice")
            seen.add(item["slice"])
            epoch = item["epoch" if grant else "minimum"]
            if type(epoch) is not int or not 0 <= epoch < (1 << 64): raise ValueError("epoch")
            if grant and item["policy"] != f"p{epoch}": raise ValueError("policy")
            used.append(item)
        if not used: raise ValueError("empty entries")
        return used

    def begin(self):
        if self.role != "endpoint": raise ValueError("role")
        self.abort(clear_peer=True); self.phase = "WAIT_M2"
        ek, self.dk = self.timed("ML-KEM.KeyGen", self.kem.generate_keypair)
        ctN, ssN = self.timed("concealment.Encaps", self.kem.encrypt, self.npk)
        rho = os.urandom(32)
        self.kpriv = expand(extract(H(ctN), ssN), pack(b"conceal", self.P, rho, ek))
        self.request = [{"slice": s, "role": "telemetry", "minimum": 0} for s in ("slice-A", "slice-B")]
        req = pack(b"device-1", self.inner(self.request), self.P)
        sig = self.timed("ML-DSA.Sign.request", self.signer.sign, pack(b"E", H(pack(ctN, rho, ek)), req), CONTEXT)
        A1 = pack(b"M1", self.P, ctN, rho, ek)
        y1 = AESGCM(expand(self.kpriv, pack(b"req"))).encrypt(ZERO_NONCE, pad(pack(req, sig), self.outer), A1)
        self.m1 = pack(b"M1", ctN, rho, ek, y1)
        return self.m1

    def install(self):
        peer = self.sim.endpoint if self.role == "endpoint" else self.sim.sf
        peer.reset(); peer.root = self.pending_root; peer.sid = self.T.hex()
        peer.slices = {g["slice"]: SliceState(g["epoch"], g["policy"]) for g in self.grant}
        self.sim.log("handshake_accepted", side=self.role, sid=peer.sid, granted=list(peer.slices))
        self.pending_root = self.kconf = self.kpriv = self.dk = None

    def handle(self, raw):
        try: return self._handle(raw)
        except (ValueError, KeyError, TypeError, InvalidTag, InvalidSignature, OverflowError):
            # A malformed late packet must not erase an already accepted root.
            if self.phase != "ACCEPTED": self.abort()
            raise ValueError("handshake rejected") from None

    def _handle(self, raw):
        fields = unpack(raw); kind = fields[0] if fields else b""
        if self.role == "sf" and kind == b"M1":
            if raw == self.m1 and self.phase in ("WAIT_M3", "ACCEPTED"): return self.m2
            _, ctN, rho, ek, y1 = unpack(raw, 5)
            if len(rho) != 32 or len(ek) != self.kem.PUBLIC_KEY_SIZE or len(ctN) != self.kem.CIPHERTEXT_SIZE:
                raise ValueError("framing")
            ssN = self.timed("concealment.Decaps", self.kem.decrypt, self.nsk, ctN)
            kpriv = expand(extract(H(ctN), ssN), pack(b"conceal", self.P, rho, ek))
            plain = AESGCM(expand(kpriv, pack(b"req"))).decrypt(ZERO_NONCE, y1, pack(b"M1", self.P, ctN, rho, ek))
            req, sig = unpack(unpad(plain, self.outer), 2)
            identity, padded, P = unpack(req, 3)
            if identity != b"device-1" or P != self.P: raise ValueError("identity/profile")
            requested = self.entries(padded)
            self.timed("ML-DSA.Verify.request", self.peer_verifier.verify, sig, pack(b"E", H(pack(ctN, rho, ek)), req), CONTEXT)
            grant = []
            for item in requested:
                epoch, policy, revoked = self.sim.authority[item["slice"]]
                if not revoked and epoch >= item["minimum"]:
                    grant.append({"slice": item["slice"], "role": item["role"], "epoch": epoch, "policy": policy})
            if not grant: raise ValueError("unauthorized")
            ct, ss = self.timed("session.Encaps", self.kem.encrypt, ek)
            rhoSF = os.urandom(32); encoded_grant = pack(self.inner(grant), self.P)
            sigSF = self.timed("ML-DSA.Sign.grant", self.signer.sign,
                               pack(b"SF", H(raw), rhoSF, ct, encoded_grant), CONTEXT)
            kresp = expand(kpriv, pack(b"resp", rhoSF))
            y2 = AESGCM(kresp).encrypt(ZERO_NONCE, pad(pack(encoded_grant, sigSF), self.outer),
                                      pack(b"M2", self.P, H(raw), rhoSF, ct))
            self.m1, self.m2, self.grant = raw, pack(b"M2", rhoSF, ct, y2), grant
            self.T = H(pack(CONTEXT, self.P, self.m1, self.m2, self.sfpk_hash))
            self.pending_root = extract(self.T, ss)
            self.kconf = expand(self.pending_root, pack(b"conf", self.T))
            self.phase = "WAIT_M3"; return self.m2
        if self.role == "endpoint" and kind == b"M2":
            if raw == self.m2 and self.phase in ("WAIT_M4", "ACCEPTED"): return self.m3
            if self.phase != "WAIT_M2": raise ValueError("phase")
            _, rhoSF, ct, y2 = unpack(raw, 4)
            if len(rhoSF) != 32 or len(ct) != self.kem.CIPHERTEXT_SIZE: raise ValueError("framing")
            kresp = expand(self.kpriv, pack(b"resp", rhoSF))
            plain = AESGCM(kresp).decrypt(ZERO_NONCE, y2, pack(b"M2", self.P, H(self.m1), rhoSF, ct))
            encoded_grant, sig = unpack(unpad(plain, self.outer), 2)
            padded, P = unpack(encoded_grant, 2)
            if P != self.P: raise ValueError("profile")
            grant = self.entries(padded, grant=True)
            requested = {r["slice"]: r for r in self.request}
            if any(g["slice"] not in requested or g["epoch"] < requested[g["slice"]]["minimum"] for g in grant):
                raise ValueError("grant")
            self.timed("ML-DSA.Verify.grant", self.peer_verifier.verify, sig,
                       pack(b"SF", H(self.m1), rhoSF, ct, encoded_grant), CONTEXT)
            ss = self.timed("session.Decaps", self.kem.decrypt, self.dk, ct)
            self.m2, self.grant = raw, grant
            self.T = H(pack(CONTEXT, self.P, self.m1, self.m2, self.sfpk_hash))
            self.pending_root = extract(self.T, ss); self.kconf = expand(self.pending_root, pack(b"conf", self.T))
            self.kce = hmac.digest(self.kconf, pack(b"KC-E", self.T), "sha256")
            self.m3 = pack(b"M3", self.T, self.kce); self.phase = "WAIT_M4"; return self.m3
        if self.role == "sf" and kind == b"M3":
            if raw == self.m3 and self.phase == "ACCEPTED": return self.m4
            if self.phase != "WAIT_M3": raise ValueError("phase")
            _, T, kce = unpack(raw, 3)
            expected = hmac.digest(self.kconf, pack(b"KC-E", self.T), "sha256")
            if T != self.T or not hmac.compare_digest(kce, expected): raise ValueError("confirmation")
            for g in self.grant:
                if self.sim.authority[g["slice"]] != [g["epoch"], g["policy"], False]: raise ValueError("policy changed")
            self.m3, self.m4 = raw, pack(b"M4", self.T,
                hmac.digest(self.kconf, pack(b"KC-SF", self.T, kce), "sha256"))
            self.install(); self.phase = "ACCEPTED"; return self.m4
        if self.role == "endpoint" and kind == b"M4":
            if raw == self.m4 and self.phase == "ACCEPTED": return None
            if self.phase != "WAIT_M4": raise ValueError("phase")
            _, T, tag = unpack(raw, 3)
            expected = hmac.digest(self.kconf, pack(b"KC-SF", self.T, self.kce), "sha256")
            if T != self.T or not hmac.compare_digest(tag, expected): raise ValueError("confirmation")
            self.m4 = raw; self.install(); self.phase = "ACCEPTED"; return None
        raise ValueError("unexpected handshake message")
