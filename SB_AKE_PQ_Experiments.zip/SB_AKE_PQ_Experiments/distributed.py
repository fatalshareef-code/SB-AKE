"""Loopback TCP workers and a deterministic fault-injecting relay.

Control plane is trusted test orchestration. Accepted roots remain fixtures.
"""
import argparse
import base64
import copy
import hashlib
import hmac
import json
import os
import socket
import struct
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path
from lifecycle import Lifecycle, encode, parse


def send_frame(sock, data):
    raw = encode(data)
    if len(raw) > 262144: raise ValueError("control frame too large")
    sock.sendall(struct.pack("!I", len(raw)) + raw)


def exact(sock, n):
    chunks = bytearray()
    while len(chunks) < n:
        data = sock.recv(n-len(chunks))
        if not data: raise EOFError("worker socket closed")
        chunks.extend(data)
    return bytes(chunks)


def recv_frame(sock):
    n = struct.unpack("!I", exact(sock, 4))[0]
    if n > 262144: raise ValueError("control frame too large")
    return json.loads(exact(sock, n))


def b64(raw): return base64.b64encode(raw).decode("ascii")
def unb64(raw): return base64.b64decode(raw, validate=True)


def worker(role, port, candidate, seed, credentials=None, profile="P1"):
    sock = socket.create_connection(("127.0.0.1", port), timeout=10)
    # Disable Nagle to avoid timing artifacts from short RPC frames.
    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
    sim = Lifecycle(candidate, seed)
    hs = None
    operation_cursor = 0
    if credentials:
        from pq_handshake import Handshake
        hs = Handshake(role, sim, credentials, profile)
    last_trace = 0
    seen_requests = set()
    send_frame(sock, {"role": role, "pid": os.getpid()})
    while True:
        req = recv_frame(sock)
        if req["op"] == "stop": break
        sim.t = req.get("tick", 0)
        start = time.perf_counter_ns()
        output = None
        try:
            op = req["op"]
            if op == "handshake_begin":
                if hs is None: raise ValueError("no real handshake backend")
                output = b64(hs.begin())
                seen_requests.clear()
            elif op == "handshake_receive":
                if hs is None: raise ValueError("no real handshake backend")
                previous_phase = hs.phase
                reply = hs.handle(unb64(req["raw"]))
                output = b64(reply) if reply is not None else None
                if hs.phase == "ACCEPTED" and previous_phase != "ACCEPTED": seen_requests.clear()
            elif op == "fixture":
                if hs is not None: raise ValueError("fixtures disabled in real-handshake mode")
                sim.authority = req["authority"]
                sim.generation = req["generation"]-1
                sim.establish()
                (sim.sf if role == "endpoint" else sim.endpoint).reset()
                seen_requests.clear()
            elif op == "authority":
                if role != "sf": raise ValueError("role")
                sim.authority = req["authority"]
            elif op == "change":
                if role != "sf": raise ValueError("role")
                sim.change(req["slice"])
            elif op == "retry":
                if role != "sf": raise ValueError("role")
                sim.retransmit(req["slice"])
            elif op == "timeout":
                if role != "sf": raise ValueError("role")
                sim.act(req)
            elif op == "revoke":
                if role != "sf": raise ValueError("role")
                sim.revoke(req["slice"])
            elif op == "receive":
                raw = unb64(req["raw"])
                if role == "endpoint": sim.receive_update(raw)
                else: sim.receive_ack(raw)
            elif op == "probe":
                if role != "endpoint": raise ValueError("role")
                s = req["slice"]; st = sim.endpoint.slices.get(s)
                if st:
                    body = {"sid": sim.endpoint.sid, "slice": s, "context": [st.epoch, st.policy],
                            "request_id": req["request_id"], "payload": "sensor-reading"}
                    tag = hmac.digest(sim.endpoint.key("traffic", s, body["context"]), encode(body), "sha256")
                    output = b64(encode({**body, "tag": tag.hex()}))
            elif op == "service":
                if role != "sf": raise ValueError("role")
                s = req["slice"]; st = sim.sf.slices.get(s); accepted = False; context = None
                if req.get("raw") and st and st.active and not sim.authority[s][2]:
                    msg = parse(unb64(req["raw"]))
                    if set(msg) != {"sid", "slice", "context", "request_id", "payload", "tag"}:
                        raise ValueError("probe fields")
                    body = {k: v for k, v in msg.items() if k != "tag"}
                    context = msg["context"]
                    expected = hmac.digest(sim.sf.key("traffic", s, [st.epoch, st.policy]), encode(body), "sha256")
                    identifier = (msg["sid"], msg["slice"], msg["request_id"])
                    accepted = (msg["sid"] == sim.sf.sid and msg["slice"] == s
                                and context == [st.epoch, st.policy] and identifier not in seen_requests
                                and hmac.compare_digest(expected, bytes.fromhex(msg["tag"])))
                    if accepted: seen_requests.add(identifier)
                sim.metrics["service_attempts"] += 1
                sim.metrics["service_accepted" if accepted else "service_rejected"] += 1
                if not sim.authority[s][2]:
                    sim.metrics["authorized_service_attempts"] += 1
                    if not accepted: sim.metrics["authorized_service_rejections"] += 1
                if accepted and context != sim.authority[s][:2]: sim.metrics["obsolete_policy_acceptances"] += 1
                if accepted and st.pending is not None: sim.metrics["acceptances_before_exact_ack"] += 1
                sim.log("service", slice=s, accepted=accepted, epoch=context[0] if context else None)
                output = accepted
            elif op != "status": raise ValueError(op)
            peer = sim.endpoint if role == "endpoint" else sim.sf
            outbound = [{"kind": k, "raw": b64(raw), "slice": s} for k, raw, s in sim.queue]
            sim.queue.clear()
            response = {"ok": True, "output": output, "outbound": outbound,
                        "metrics": sim.result(), "authority": sim.authority if role == "sf" else None,
                        "trace": sim.trace[last_trace:], "has_root": peer.root is not None,
                        "remote_has_root": (sim.sf if role == "endpoint" else sim.endpoint).root is not None,
                        "handler_ns": time.perf_counter_ns()-start}
            if hs is not None:
                response["handshake_phase"] = hs.phase
                response["crypto_operations"] = hs.ops[operation_cursor:]
                operation_cursor = len(hs.ops)
            last_trace = len(sim.trace)
            send_frame(sock, response)
        except Exception as exc:
            send_frame(sock, {"ok": False, "error": type(exc).__name__+": "+str(exc)})
    sock.close()


class DistributedRun:
    def __init__(self, candidate, seed, delay_ticks=2, wall_delay_ms=0, credentials=None, profile="P1"):
        self.candidate, self.seed = candidate, seed
        self.delay_ticks, self.wall_delay_ms = delay_ticks, wall_delay_ms
        self.credentials, self.profile = credentials, profile
        self.handshake_measurements, self.crypto_operations = [], []
        self.listener = socket.socket(); self.listener.bind(("127.0.0.1", 0)); self.listener.listen(2)
        self.listener.settimeout(10)
        self.children, self.sockets = {}, {}
        self.pid_history, self.trace, self.messages = [], [], []
        self.metrics, self.saved_metrics, self.last = {}, {r: Counter() for r in ("endpoint", "sf")}, {}
        self.timings = []
        self.authority = {s: [0, "p0", False] for s in ("slice-A", "slice-B")}
        self.generation = self.tick = self.request_id = 0
        for role in ("endpoint", "sf"): self.start(role)

    def start(self, role):
        command = [sys.executable, str(Path(__file__).resolve()), "--worker", role,
                                 "--port", str(self.listener.getsockname()[1]), "--candidate", self.candidate,
                                 "--seed", str(self.seed)]
        if self.credentials: command += ["--credentials", str(self.credentials), "--profile", self.profile]
        proc = subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        self.children[role] = proc
        conn, _ = self.listener.accept(); conn.settimeout(10)
        conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        hello = recv_frame(conn)
        if hello["role"] != role: raise RuntimeError("wrong worker role")
        self.sockets[role] = conn
        self.pid_history.append({"role": role, "pid": hello["pid"], "tick": self.tick})

    def call(self, role, op, **fields):
        t = time.perf_counter_ns()
        send_frame(self.sockets[role], {"op": op, "tick": self.tick, **fields})
        res = recv_frame(self.sockets[role])
        self.timings.append({"role": role, "op": op, "rpc_ns": time.perf_counter_ns()-t,
                             "handler_ns": res.get("handler_ns")})
        if not res["ok"]: raise RuntimeError(res["error"])
        if res["remote_has_root"]: raise RuntimeError("worker retained other role's root")
        self.last[role] = res
        self.metrics[role] = res["metrics"]
        self.crypto_operations.extend(res.get("crypto_operations", []))
        self.trace.extend({"role": role, **entry} for entry in res["trace"])
        if role == "sf": self.authority = copy.deepcopy(res["authority"])
        for message in res["outbound"]:
            self.messages.append({**message, "source": role})
        return res["output"]

    def establish(self, drop_once=None):
        if self.credentials: return self.real_handshake(drop_once)
        self.generation += 1
        for role in ("sf", "endpoint"):
            self.call(role, "fixture", authority=copy.deepcopy(self.authority), generation=self.generation)

    def real_handshake(self, drop_once=None):
        """Four messages, with optional single lost M2 or M4 and cached retry."""
        self.generation += 1
        start = time.perf_counter_ns(); handler_before = len(self.timings)
        operations_before = len(self.crypto_operations)
        wires = []; retries = 0
        def forward(role, raw):
            message = unb64(raw)
            from pq_handshake import unpack
            kind = unpack(message)[0].decode()
            wires.append({"kind": kind, "bytes": len(message)})
            if self.wall_delay_ms: time.sleep(self.wall_delay_ms/1000)
            return self.call(role, "handshake_receive", raw=raw)
        m1 = self.call("endpoint", "handshake_begin")
        m2 = forward("sf", m1)
        if drop_once == "M2":
            wires.append({"kind": "M2", "bytes": len(unb64(m2)), "dropped": True})
            # Immediate prescribed retry: no real timeout wait is charged.
            m2 = forward("sf", m1); retries += 1
        m3 = forward("endpoint", m2)
        m4 = forward("sf", m3)
        if drop_once == "M4":
            wires.append({"kind": "M4", "bytes": len(unb64(m4)), "dropped": True})
            m4 = forward("sf", m3); retries += 1
        forward("endpoint", m4)
        elapsed = time.perf_counter_ns()-start
        if any(self.last[r].get("handshake_phase") != "ACCEPTED" or not self.last[r]["has_root"]
               for r in ("endpoint", "sf")): raise RuntimeError("handshake not accepted at both peers")
        self.handshake_measurements.append({"profile": self.profile, "association": self.generation,
            "category": "initial" if self.generation == 1 else "reauthorization",
            "elapsed_ns": elapsed, "handler_ns": sum(x["handler_ns"] for x in self.timings[handler_before:]),
            "crypto_ns": sum(x["ns"] for x in self.crypto_operations[operations_before:]),
            "protocol_bytes_sent": sum(x["bytes"] for x in wires), "retries": retries,
            "drop_once": drop_once, "messages": wires})

    def restart(self, role):
        self.call(role, "status")
        self.saved_metrics[role].update(self.metrics[role])
        old_pid = self.children[role].pid
        self.children[role].kill(); self.children[role].wait(timeout=5)
        self.children[role].stderr.close(); self.sockets[role].close()
        self.start(role)
        if role == "sf": self.call(role, "authority", authority=copy.deepcopy(self.authority))
        else: self.call(role, "status")
        if self.last[role]["has_root"]: raise RuntimeError("root survived process restart")
        self.trace.append({"role": "relay", "tick": self.tick, "event": "process_restart",
                           "side": role, "old_pid": old_pid, "new_pid": self.children[role].pid})

    def deliver(self, kind, s, drop=False, duplicate=False, delay=False):
        for i, msg in enumerate(self.messages):
            if msg["kind"] != kind or msg["slice"] != s or msg.get("due", -1) > self.tick: continue
            if delay:
                msg["due"] = self.tick+self.delay_ticks
                self.trace.append({"role": "relay", "tick": self.tick, "event": "delay",
                                   "kind": kind, "slice": s, "due": msg["due"]})
                return
            self.messages.pop(i)
            if drop:
                self.trace.append({"role": "relay", "tick": self.tick, "event": "drop", "kind": kind, "slice": s})
                return
            if self.wall_delay_ms: time.sleep(self.wall_delay_ms/1000)
            target = "endpoint" if kind == "UPD" else "sf"
            self.call(target, "receive", raw=msg["raw"])
            if duplicate: self.call(target, "receive", raw=msg["raw"])
            self.trace.append({"role": "relay", "tick": self.tick, "event": "delivered", "kind": kind,
                               "slice": s, "copies": 2 if duplicate else 1,
                               "message_sha256": hashlib.sha256(unb64(msg["raw"])).hexdigest()})
            return
        self.trace.append({"role": "relay", "tick": self.tick, "event": "delivery_no_message", "kind": kind, "slice": s})

    def act(self, e):
        self.tick = e["tick"]; op = e["op"]; s = e.get("slice", "slice-A")
        if op == "establish": self.establish()
        elif op == "restart": self.restart(e["side"])
        elif op in ("change", "retry", "timeout", "revoke"): self.call("sf", op, slice=s)
        elif op == "deliver": self.deliver(e["kind"], s, e.get("drop", False), e.get("duplicate", False), e.get("delay", False))
        elif op == "service":
            self.request_id += 1
            raw = self.call("endpoint", "probe", slice=s, request_id=self.request_id)
            self.call("sf", "service", slice=s, raw=raw)
        else: raise ValueError(op)

    def result(self):
        self.call("endpoint", "status"); self.call("sf", "status")
        merged = Counter()
        for role in ("endpoint", "sf"):
            merged.update(self.saved_metrics[role]); merged.update(self.metrics[role])
        # Each fixture is provisioned to two peers but counts as one association.
        merged["accepted_root_fixtures"] = 0 if self.credentials else self.generation
        if self.credentials: merged["completed_handshakes"] = len(self.handshake_measurements)
        return dict(merged)

    def close(self):
        for role, proc in self.children.items():
            if proc.poll() is None:
                try: send_frame(self.sockets[role], {"op": "stop"}); proc.wait(timeout=3)
                except (OSError, subprocess.TimeoutExpired): proc.kill(); proc.wait(timeout=3)
            self.sockets[role].close(); proc.stderr.close()
        self.listener.close()


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--worker", choices=["endpoint", "sf"], required=True)
    ap.add_argument("--port", type=int, required=True); ap.add_argument("--candidate", required=True)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--credentials"); ap.add_argument("--profile", choices=["P1", "P2"], default="P1")
    args = ap.parse_args(); worker(args.worker, args.port, args.candidate, args.seed, args.credentials, args.profile)
