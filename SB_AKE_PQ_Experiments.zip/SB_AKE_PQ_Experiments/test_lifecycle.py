import unittest
import hmac
from lifecycle import Lifecycle, MAX_Q, encode, parse, digest
from run_experiments import scenario


class LifecycleTests(unittest.TestCase):
    def sim(self, candidate="sbake", control=None):
        sim = Lifecycle(candidate, control=control)
        sim.establish()
        return sim

    def scenario_run(self, name, candidate="sbake"):
        sim = Lifecycle(candidate)
        for step in scenario(name, 0): sim.act(step)
        return sim

    def test_honest_round_trip(self):
        s = self.scenario_run("normal")
        self.assertEqual(s.metrics["committed_updates"], 1)
        self.assertEqual(s.metrics["acceptances_before_exact_ack"], 0)
        self.assertTrue(s.service("slice-A"))

    def test_lost_ack_retransmits_identical_bytes(self):
        s = self.scenario_run("lost_ack")
        upd = [t["digest"] for t in s.trace if t["event"] == "send" and t["kind"] == "UPD"]
        self.assertEqual(upd[0], upd[1])
        self.assertEqual(s.metrics["installations"], 1)
        self.assertEqual(s.metrics["committed_updates"], 1)

    def test_duplicate_safe_and_diagnostic_baseline(self):
        self.assertEqual(self.scenario_run("duplicate_update").metrics["duplicate_installations"], 0)
        self.assertEqual(self.scenario_run("duplicate_update", "generic_minimal").metrics["duplicate_installations"], 1)

    def test_activation_guard_detected(self):
        self.assertEqual(self.scenario_run("normal", "generic_minimal").metrics["acceptances_before_exact_ack"], 1)

    def test_second_change_invalidates(self):
        s = self.sim(); s.change("slice-A"); s.change("slice-A")
        self.assertIsNone(s.sf.slices["slice-A"].pending)
        s.deliver("UPD"); s.deliver("ACK")
        self.assertFalse(s.service("slice-A"))

    def test_revocation_inflight_does_not_imply_endpoint_erasure(self):
        s = self.sim(); s.change("slice-A"); s.revoke("slice-A"); s.deliver("UPD"); s.deliver("ACK")
        self.assertEqual(s.endpoint.slices["slice-A"].epoch, 1)
        self.assertFalse(s.service("slice-A"))

    def test_revocation_control_is_detected(self):
        s = self.sim(control="omit_revocation_guard"); s.revoke("slice-A")
        self.assertTrue(s.service("slice-A"))
        self.assertEqual(s.metrics["revoked_service_acceptances"], 1)

    def test_both_restart_sides_clear_root(self):
        for side in ("endpoint", "sf"):
            s = self.sim(); s.restart(side)
            self.assertFalse(s.service("slice-A"))
            self.assertIsNone((s.endpoint if side == "endpoint" else s.sf).root)
            s.establish(); self.assertTrue(s.service("slice-A"))

    def test_restart_control_is_detected(self):
        s = self.sim(control="resume_after_restart"); s.restart("endpoint")
        self.assertTrue(s.service("slice-A"))
        # This witnesses the forbidden resume behavior, not a cryptographic attack.

    def test_old_root_messages_rejected(self):
        s = self.sim(); s.change("slice-A"); old = s.sf.slices["slice-A"].pending
        s.establish(); s.receive_update(old)
        self.assertEqual(s.metrics["installations"], 0)

    def test_old_ack_cannot_commit_new_root(self):
        s = self.sim(); s.change("slice-A"); s.deliver("UPD")
        ack = s.endpoint.slices["slice-A"].last_ack
        s.establish(); s.change("slice-A"); s.receive_ack(ack)
        self.assertFalse(s.sf.slices["slice-A"].active)

    def test_ciphertext_tamper(self):
        s = self.sim(); s.change("slice-A"); msg = parse(s.sf.slices["slice-A"].pending)
        ct = bytearray.fromhex(msg["ct"]); ct[0] ^= 1; msg["ct"] = ct.hex()
        s.receive_update(encode(msg))
        self.assertEqual(s.metrics["installations"], 0)

    def test_cross_slice_substitution(self):
        s = self.sim(); s.change("slice-A"); msg = parse(s.sf.slices["slice-A"].pending)
        msg["slice"] = "slice-B"; s.receive_update(encode(msg))
        self.assertEqual(s.metrics["installations"], 0)

    def test_wrong_ack_mac(self):
        s = self.sim(); s.change("slice-A"); s.deliver("UPD")
        msg = parse(s.endpoint.slices["slice-A"].last_ack); msg["tag"] = "00"*32
        s.receive_ack(encode(msg)); self.assertFalse(s.sf.slices["slice-A"].active)

    def test_exact_digest_guard_in_isolation(self):
        # White-box control supplies a valid MAC on a wrong digest; this is not
        # an attacker-forgeable message under the uncompromised-key assumption.
        for control, expected in ((None, False), ("omit_ack_digest", True)):
            s = self.sim(control=control); s.change("slice-A"); s.deliver("UPD")
            msg = parse(s.endpoint.slices["slice-A"].last_ack); msg.pop("tag"); msg["digest"] = "00"*32
            msg["tag"] = hmac.digest(s.endpoint.key("ack", "slice-A"), encode(msg), "sha256").hex()
            s.receive_ack(encode(msg)); self.assertEqual(s.sf.slices["slice-A"].active, expected)

    def test_counter_exhaustion(self):
        s = self.sim(); s.sf.slices["slice-A"].q = MAX_Q; s.change("slice-A")
        self.assertFalse(s.sf.slices["slice-A"].active)
        self.assertIsNone(s.sf.slices["slice-A"].pending)

    def test_parser_rejects_duplicate_and_noncanonical_fields(self):
        for raw in (b'{"q":1,"q":2}', b'{ "q":1}', b'[]\n', b'x'*4097):
            with self.assertRaises(ValueError): parse(raw)

    def test_late_ack_after_timeout(self):
        s = self.sim(); s.change("slice-A"); s.deliver("UPD"); s.invalidate("slice-A", "timeout")
        s.deliver("ACK"); self.assertFalse(s.sf.slices["slice-A"].active)

    def test_timeout_without_pending_does_not_disable_service(self):
        s = self.sim(); s.act({"tick": 1, "op": "timeout"})
        self.assertTrue(s.service("slice-A"))

    def test_multiple_committed_epochs(self):
        s = self.sim()
        for epoch in range(1, 6):
            s.change("slice-A"); s.deliver("UPD"); s.deliver("ACK")
            self.assertEqual(s.sf.slices["slice-A"].epoch, epoch)
            self.assertTrue(s.service("slice-A"))
        self.assertEqual(s.metrics["installations"], 5)

    def test_older_update_after_new_commit_is_rejected(self):
        s = self.sim(); s.change("slice-A"); old = s.sf.slices["slice-A"].pending
        s.deliver("UPD"); s.deliver("ACK"); s.change("slice-A"); s.deliver("UPD"); s.deliver("ACK")
        s.receive_update(old)
        self.assertEqual(s.endpoint.slices["slice-A"].epoch, 2)
        self.assertEqual(s.metrics["installations"], 2)

    def test_duplicate_ack_does_not_recommit(self):
        s = self.sim(); s.change("slice-A"); s.deliver("UPD"); s.deliver("ACK", duplicate=True)
        self.assertEqual(s.metrics["committed_updates"], 1)

    def test_two_slices_independent(self):
        s = self.sim(); s.change("slice-A")
        self.assertTrue(s.service("slice-B")); self.assertFalse(s.service("slice-A"))

    def test_guarded_candidates_identical(self):
        for name in ("lost_ack", "duplicate_update", "pending_policy_change", "revocation_in_flight", "sf_restart"):
            a = self.scenario_run(name); b = self.scenario_run(name, "generic_guarded")
            self.assertEqual(a.result(), b.result()); self.assertEqual(a.trace, b.trace)


if __name__ == "__main__": unittest.main()
