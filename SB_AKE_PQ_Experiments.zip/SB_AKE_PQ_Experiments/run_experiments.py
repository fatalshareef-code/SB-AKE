"""Run identical prerecorded schedules against three lifecycle candidates."""
import argparse
import csv
import hashlib
import json
import platform
import random
from pathlib import Path
import cryptography
from lifecycle import Lifecycle

CANDIDATES = ("generic_minimal", "generic_guarded", "sbake")


def event(tick, op, **kw):
    return {"tick": tick, "op": op, **kw}


def scenario(name, seed):
    rng = random.Random(seed)
    out = [event(0, "establish"), event(1, "service"), event(2, "change")]
    if name == "normal":
        out += [event(3, "deliver", kind="UPD"), event(4, "service"), event(5, "deliver", kind="ACK")]
    elif name == "lost_ack":
        out += [event(3, "deliver", kind="UPD"), event(4, "deliver", kind="ACK", drop=True),
                event(5, "service"), event(6, "retry"), event(7, "deliver", kind="UPD"),
                event(8, "deliver", kind="ACK")]
    elif name == "duplicate_update":
        out += [event(3, "deliver", kind="UPD", duplicate=True), event(4, "deliver", kind="ACK"),
                event(5, "deliver", kind="ACK")]
    elif name == "pending_policy_change":
        out += [event(3, "deliver", kind="UPD"), event(4, "change"),
                event(5, "deliver", kind="ACK"), event(6, "deliver", kind="UPD"),
                event(7, "service"), event(8, "establish")]
    elif name == "revocation_in_flight":
        out += [event(3, "revoke"), event(4, "deliver", kind="UPD"),
                event(5, "deliver", kind="ACK"), event(6, "service"), event(7, "establish")]
    elif name in ("endpoint_restart", "sf_restart"):
        out += [event(3, "deliver", kind="UPD"), event(4, "restart", side="endpoint" if name == "endpoint_restart" else "sf"),
                event(5, "deliver", kind="ACK"), event(6, "retry"),
                event(7, "deliver", kind="UPD"), event(8, "service"), event(9, "establish")]
    elif name == "permanent_ack_loss":
        out += [event(3, "deliver", kind="UPD"), event(4, "deliver", kind="ACK", drop=True)]
        for j in range(3):
            t = 5 + 4*j
            out += [event(t, "retry"), event(t+1, "deliver", kind="UPD"),
                    event(t+2, "deliver", kind="ACK", drop=True), event(t+3, "service")]
        out += [event(17, "timeout"), event(18, "establish")]
    elif name == "two_slice_interleaving":
        out += [event(3, "change", slice="slice-B"), event(4, "deliver", kind="UPD", slice="slice-B"),
                event(5, "deliver", kind="UPD", duplicate=True), event(6, "deliver", kind="ACK", slice="slice-B"),
                event(7, "service", slice="slice-B"), event(8, "deliver", kind="ACK")]
    elif name == "random_loss_duplicates":
        # Exogenous decisions generated once, independent of any candidate execution.
        t = 3
        for attempt in range(4):
            if attempt:
                out.append(event(t, "retry")); t += 1
            out += [event(t, "deliver", kind="UPD", drop=rng.random() < .25, duplicate=rng.random() < .3),
                    event(t+1, "service"),
                    event(t+2, "deliver", kind="ACK", drop=rng.random() < .4, duplicate=rng.random() < .2)]
            t += 3
        # Fixed cleanup is also identical, regardless of whether ACK was received.
        out += [event(t, "timeout"), event(t+1, "establish")]
    else:
        raise ValueError(name)
    out += [event(out[-1]["tick"]+1, "service"), event(out[-1]["tick"]+2, "service", slice="slice-B")]
    return out


NAMES = ("normal", "lost_ack", "duplicate_update", "pending_policy_change", "revocation_in_flight",
         "endpoint_restart", "sf_restart", "permanent_ack_loss", "two_slice_interleaving", "random_loss_duplicates")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=100)
    ap.add_argument("--out", type=Path, default=Path("results"))
    args = ap.parse_args()
    if args.seeds < 1: ap.error("--seeds must be positive")
    args.out.mkdir(parents=True, exist_ok=True)
    rows, schedules, mismatch, safety_failures = [], [], [], []
    for name in NAMES:
        for seed in range(args.seeds):
            steps = scenario(name, seed)
            schedule_hash = hashlib.sha256(json.dumps(steps, sort_keys=True).encode()).hexdigest()
            schedules.append({"scenario": name, "seed": seed, "sha256": schedule_hash, "events": steps})
            outcomes = {}
            traces = {}
            for candidate in CANDIDATES:
                sim = Lifecycle(candidate, seed)
                for step in steps: sim.act(step)
                outcomes[candidate] = sim.result()
                traces[candidate] = sim.trace
                rows.append({"scenario": name, "seed": seed, "candidate": candidate,
                             "schedule_sha256": schedule_hash, **sim.result()})
                if candidate != "generic_minimal":
                    for metric in ("duplicate_installations", "obsolete_policy_acceptances",
                                   "revoked_service_acceptances", "acceptances_before_exact_ack"):
                        if sim.metrics[metric]: safety_failures.append([name, seed, candidate, metric])
            if outcomes["sbake"] != outcomes["generic_guarded"] or traces["sbake"] != traces["generic_guarded"]:
                mismatch.append([name, seed])
            if seed == 0:
                (args.out / f"trace_{name}.json").write_text(json.dumps(traces, indent=2))
    with (args.out / "runs.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    (args.out / "schedules.json").write_text(json.dumps(schedules, indent=2))
    numeric = [k for k in rows[0] if k not in ("scenario", "seed", "candidate", "schedule_sha256")]
    aggregate = []
    for name in NAMES:
        for candidate in CANDIDATES:
            selected = [r for r in rows if r["scenario"] == name and r["candidate"] == candidate]
            aggregate.append({"scenario": name, "candidate": candidate, "runs": len(selected),
                              **{k: sum(r[k] for r in selected)/len(selected) for k in numeric}})
    with (args.out / "summary.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(aggregate[0])); w.writeheader(); w.writerows(aggregate)
    summary = {"scope": "in-process authenticated lifecycle prototype with preaccepted root fixtures",
               "python": platform.python_version(), "cryptography": cryptography.__version__,
               "seeds": args.seeds, "scenarios": len(NAMES), "candidate_runs": len(rows),
               "guarded_safety_failures": safety_failures, "guarded_pair_mismatches": mismatch,
               "handshake_measured": False, "hardware_measured": False,
               "time_unit": "scripted event ticks, not milliseconds"}
    (args.out / "run_metadata.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))
    if safety_failures or mismatch: raise SystemExit(1)


if __name__ == "__main__": main()
