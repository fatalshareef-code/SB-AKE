"""Executable lifecycle prototype. Not an ML-KEM/ML-DSA handshake implementation."""
from dataclasses import dataclass, field
import hashlib
import hmac
import json
from collections import Counter
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag

MAX_Q = (1 << 96) - 1
PROFILE = "SB-AKE-lifecycle-prototype-1"


def encode(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()


def parse(raw):
    def unique(pairs):
        result = {}
        for k, v in pairs:
            if k in result:
                raise ValueError("duplicate field")
            result[k] = v
        return result
    if not isinstance(raw, bytes) or len(raw) > 4096:
        raise ValueError("framing")
    value = json.loads(raw, object_pairs_hook=unique)
    if encode(value) != raw:
        raise ValueError("noncanonical encoding")
    return value


def expand(key, fields):
    # HKDF-Expand SHA-256, one 32-byte block; supplied root is already a PRK.
    return hmac.digest(key, encode(fields) + b"\x01", "sha256")


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def integer(v):
    return type(v) is int and v >= 0


@dataclass
class SliceState:
    epoch: int
    policy: str
    q: int = 0
    active: bool = True
    pending: bytes | None = None
    pending_context: tuple | None = None
    last_digest: str | None = None
    last_ack: bytes | None = None


@dataclass
class Peer:
    root: bytes | None = None
    sid: str | None = None
    slices: dict = field(default_factory=dict)

    def reset(self):
        # Logical deletion only: Python cannot guarantee physical memory zeroization.
        self.root = self.sid = None
        self.slices.clear()

    def key(self, label, s, context=None):
        if self.root is None:
            raise ValueError("no accepted root")
        return expand(self.root, [label, PROFILE, self.sid, "device-1", s, "telemetry", context])


class Lifecycle:
    def __init__(self, candidate, seed=0, control=None):
        if candidate not in {"generic_minimal", "generic_guarded", "sbake"}:
            raise ValueError(candidate)
        self.candidate, self.seed, self.control = candidate, seed, control
        self.guarded = candidate != "generic_minimal"
        self.endpoint, self.sf = Peer(), Peer()
        self.authority = {s: [0, "p0", False] for s in ("slice-A", "slice-B")}
        self.generation = 0
        self.metrics = Counter()
        self.trace = []
        self.installations = Counter()
        self.queue = []
        self.snapshots = {}
        self.t = 0
        self.request_id = 0

    def log(self, event, **details):
        self.trace.append({"tick": self.t, "event": event, **details})

    def establish(self):
        # Fixture for a mutually accepted authenticated fresh root, NOT an AKE.
        self.generation += 1
        root = hashlib.sha256(encode(["TEST-ONLY-ROOT", self.seed, self.generation])).digest()
        sid = digest(encode(["TEST-ONLY-TRANSCRIPT", self.seed, self.generation]))
        for peer in (self.endpoint, self.sf):
            peer.reset()
            peer.root, peer.sid = root, sid
            peer.slices = {s: SliceState(ep, policy) for s, (ep, policy, revoked)
                           in self.authority.items() if not revoked}
        self.metrics["accepted_root_fixtures"] += 1
        self.log("fresh_authorization_fixture", sid=sid, granted=list(self.sf.slices))

    def send(self, kind, raw, s):
        self.queue.append((kind, raw, s))
        self.metrics["messages_sent"] += 1
        self.metrics["encoded_bytes_sent"] += len(raw)
        self.log("send", kind=kind, slice=s, digest=digest(raw), bytes=len(raw))

    def invalidate(self, s, reason):
        st = self.sf.slices.get(s)
        if st:
            st.active = False
            st.pending = st.pending_context = None
        self.log("invalidated", slice=s, reason=reason)
        self.metrics["fresh_authorization_required"] += 1

    def change(self, s):
        auth = self.authority[s]
        auth[0] += 1
        auth[1] = f"p{auth[0]}"
        st = self.sf.slices.get(s)
        if not st or auth[2]:
            return self.log("policy_change_without_live_grant", slice=s)
        if not st.active and st.pending is None:
            return self.log("policy_change_requires_fresh_authorization", slice=s)
        if st.pending is not None and self.guarded:
            return self.invalidate(s, "second_policy_change_while_pending")
        if st.q == MAX_Q:
            return self.invalidate(s, "counter_exhaustion")
        st.q += 1
        header = {"kind": "UPD", "sid": self.sf.sid, "slice": s, "q": st.q}
        aad = encode(["UPD", PROFILE, "device-1", "telemetry", header])
        payload = encode({"old": st.epoch, "new": auth[0], "policy": auth[1]})
        ct = AESGCM(self.sf.key("upd", s)).encrypt(st.q.to_bytes(12, "big"), payload, aad)
        raw = encode({**header, "ct": ct.hex()})
        st.pending, st.pending_context = raw, (auth[0], auth[1])
        if self.guarded:
            st.active = False
        else:
            st.epoch, st.policy = auth[:2]  # Optimistic activation, diagnostic comparator.
        self.log("update_issued", slice=s, sid=self.sf.sid, q=st.q)
        self.send("UPD", raw, s)

    def retransmit(self, s):
        st = self.sf.slices.get(s)
        if st and st.pending is not None:
            self.metrics["update_retransmissions"] += 1
            self.send("UPD", st.pending, s)

    def receive_update(self, raw):
        try:
            msg = parse(raw)
            if set(msg) != {"kind", "sid", "slice", "q", "ct"} or msg["kind"] != "UPD":
                raise ValueError("fields")
            s, q = msg["slice"], msg["q"]
            if not integer(q) or not 0 < q <= MAX_Q or msg["sid"] != self.endpoint.sid:
                raise ValueError("selector")
            st = self.endpoint.slices[s]
            header = {k: msg[k] for k in ("kind", "sid", "slice", "q")}
            aad = encode(["UPD", PROFILE, "device-1", "telemetry", header])
            data = parse(AESGCM(self.endpoint.key("upd", s)).decrypt(
                q.to_bytes(12, "big"), bytes.fromhex(msg["ct"]), aad))
            if set(data) != {"old", "new", "policy"} or not all(integer(data[k]) for k in ("old", "new")):
                raise ValueError("payload")
            if type(data["policy"]) is not str or data["policy"] != f"p{data['new']}":
                raise ValueError("application policy")
            d = digest(raw)
            if self.guarded and q == st.q and d == st.last_digest:
                self.metrics["duplicate_updates_handled"] += 1
                self.send("ACK", st.last_ack, s)
                return
            if self.guarded and (q <= st.q or data["old"] != st.epoch or data["new"] <= st.epoch):
                raise ValueError("state guard")
            # Atomic local transaction: state and cached ACK become visible together.
            st.epoch, st.policy, st.q = data["new"], data["policy"], q
            ack = {"kind": "ACK", "sid": msg["sid"], "slice": s, "q": q, "digest": d}
            tag = hmac.digest(self.endpoint.key("ack", s), encode(ack), "sha256")
            st.last_digest, st.last_ack = d, encode({**ack, "tag": tag.hex()})
            identity = (self.endpoint.sid, s, q)
            self.installations[identity] += 1
            self.metrics["installations"] += 1
            if self.installations[identity] > 1:
                self.metrics["duplicate_installations"] += 1
            self.log("installed", slice=s, sid=self.endpoint.sid, q=q, epoch=st.epoch)
            self.send("ACK", st.last_ack, s)
        except (ValueError, KeyError, TypeError, OverflowError, InvalidTag) as exc:
            # Uniform external reject; exception type only used internally for diagnostics.
            self.metrics["rejected_updates"] += 1
            self.log("update_rejected", diagnostic=type(exc).__name__)

    def receive_ack(self, raw):
        try:
            msg = parse(raw)
            if set(msg) != {"kind", "sid", "slice", "q", "digest", "tag"} or msg["kind"] != "ACK":
                raise ValueError("fields")
            s = msg["slice"]
            if msg["sid"] != self.sf.sid or not integer(msg["q"]):
                raise ValueError("selector")
            st = self.sf.slices[s]
            ack = {k: v for k, v in msg.items() if k != "tag"}
            expected = hmac.digest(self.sf.key("ack", s), encode(ack), "sha256")
            if not hmac.compare_digest(expected, bytes.fromhex(msg["tag"])):
                raise ValueError("MAC")
            if st.pending is None or msg["q"] != st.q:
                raise ValueError("no matching pending update")
            if self.control != "omit_ack_digest" and msg["digest"] != digest(st.pending):
                raise ValueError("update digest")
            if self.authority[s][2]:
                raise ValueError("revoked")
            if tuple(self.authority[s][:2]) != st.pending_context:
                raise ValueError("policy superseded")
            st.epoch, st.policy = st.pending_context
            st.active = True
            st.pending = st.pending_context = None
            self.metrics["committed_updates"] += 1
            self.log("ack_committed", slice=s, q=st.q)
        except (ValueError, KeyError, TypeError, OverflowError) as exc:
            self.metrics["rejected_acks"] += 1
            self.log("ack_rejected", diagnostic=type(exc).__name__)

    def deliver(self, kind, s="slice-A", drop=False, duplicate=False):
        for i, (k, raw, sl) in enumerate(self.queue):
            if k == kind and sl == s:
                self.queue.pop(i)
                if drop:
                    self.metrics[f"dropped_{kind.lower()}"] += 1
                    self.log("network_drop", kind=kind, slice=s)
                    return
                fn = self.receive_update if kind == "UPD" else self.receive_ack
                self.log("deliver", kind=kind, slice=s, digest=digest(raw))
                fn(raw)
                if duplicate:
                    self.metrics["network_duplicates"] += 1
                    fn(raw)
                return
        self.log("delivery_no_message", kind=kind, slice=s)

    def revoke(self, s):
        self.authority[s][2] = True
        if self.control != "omit_revocation_guard":
            self.invalidate(s, "revocation")
        self.log("revoked_at_sf", slice=s)

    def restart(self, side):
        peer = self.endpoint if side == "endpoint" else self.sf
        if self.control != "resume_after_restart":
            peer.reset()
        self.log("restart", side=side)

    def service(self, s):
        self.request_id += 1
        ep, sf = self.endpoint, self.sf
        est, sst = ep.slices.get(s), sf.slices.get(s)
        accepted = False
        if est and sst and ep.sid == sf.sid and sst.active:
            context = [est.epoch, est.policy]
            request = encode([ep.sid, s, context, self.request_id, "sensor-reading"])
            tag = hmac.digest(ep.key("traffic", s, context), request, "sha256")
            expected = hmac.digest(sf.key("traffic", s, [sst.epoch, sst.policy]), request, "sha256")
            accepted = hmac.compare_digest(tag, expected)
            if self.control != "omit_revocation_guard" and self.authority[s][2]:
                accepted = False
        self.metrics["service_attempts"] += 1
        self.metrics["service_accepted" if accepted else "service_rejected"] += 1
        if not self.authority[s][2]:
            self.metrics["authorized_service_attempts"] += 1
            if not accepted:
                self.metrics["authorized_service_rejections"] += 1
        if accepted and self.authority[s][2]:
            self.metrics["revoked_service_acceptances"] += 1
        if accepted and [est.epoch, est.policy] != self.authority[s][:2]:
            self.metrics["obsolete_policy_acceptances"] += 1
        if accepted and sst.pending is not None:
            self.metrics["acceptances_before_exact_ack"] += 1
        self.log("service", slice=s, accepted=accepted, epoch=est.epoch if est else None)
        return accepted

    def act(self, event):
        self.t = event["tick"]
        op, s = event["op"], event.get("slice", "slice-A")
        if op == "establish": self.establish()
        elif op == "change": self.change(s)
        elif op == "retry": self.retransmit(s)
        elif op == "deliver": self.deliver(event["kind"], s, event.get("drop", False), event.get("duplicate", False))
        elif op == "revoke": self.revoke(s)
        elif op == "restart": self.restart(event["side"])
        elif op == "timeout":
            st = self.sf.slices.get(s)
            if st and st.pending is not None:
                self.invalidate(s, "retry_timeout")
            else:
                self.log("timeout_no_pending_update", slice=s)
        elif op == "service": self.service(s)
        else: raise ValueError(op)

    def result(self):
        names = ["accepted_root_fixtures", "messages_sent", "encoded_bytes_sent", "installations",
                 "duplicate_installations", "committed_updates", "duplicate_updates_handled",
                 "service_attempts", "service_accepted", "service_rejected", "authorized_service_attempts",
                 "authorized_service_rejections", "obsolete_policy_acceptances", "revoked_service_acceptances",
                 "acceptances_before_exact_ack", "update_retransmissions", "fresh_authorization_required"]
        return {k: self.metrics[k] for k in names}
