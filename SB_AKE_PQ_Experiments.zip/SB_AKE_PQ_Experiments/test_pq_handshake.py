import base64
import tempfile
import unittest
from pathlib import Path
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDFExpand
from lifecycle import Lifecycle
from pq_handshake import Handshake, provision, pack, unpack, pad, unpad, expand
from distributed import DistributedRun


class HandshakeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        for p in ("P1", "P2"): provision(cls.temp.name, p)

    @classmethod
    def tearDownClass(cls): cls.temp.cleanup()

    def pair(self, profile="P1"):
        ep, sf = Lifecycle("sbake"), Lifecycle("sbake")
        return Handshake("endpoint", ep, self.temp.name, profile), Handshake("sf", sf, self.temp.name, profile)

    def complete(self, ep, sf):
        m1 = ep.begin(); m2 = sf.handle(m1); m3 = ep.handle(m2); m4 = sf.handle(m3); ep.handle(m4)
        return m1, m2, m3, m4

    def test_both_profiles_match_roots_and_exports(self):
        for p in ("P1", "P2"):
            ep, sf = self.pair(p); self.complete(ep, sf)
            self.assertEqual(ep.sim.endpoint.root, sf.sim.sf.root)
            for s in ("slice-A", "slice-B"):
                for label, ctx in (("upd", None), ("ack", None), ("traffic", [0, "p0"])):
                    self.assertEqual(ep.sim.endpoint.key(label, s, ctx), sf.sim.sf.key(label, s, ctx))
            self.assertIsNone(ep.dk); self.assertIsNone(ep.pending_root); self.assertIsNone(sf.kconf)

    def test_fresh_run_changes_root_and_nonce(self):
        ep, sf = self.pair(); a = self.complete(ep, sf); root = ep.sim.endpoint.root
        b = self.complete(ep, sf)
        self.assertNotEqual(a[0], b[0]); self.assertNotEqual(root, ep.sim.endpoint.root)

    def test_duplicate_m1_m2_m3_m4_cached(self):
        ep, sf = self.pair(); m1 = ep.begin(); m2 = sf.handle(m1); n = len(sf.ops)
        self.assertEqual(sf.handle(m1), m2); self.assertEqual(len(sf.ops), n)
        m3 = ep.handle(m2); n = len(ep.ops)
        self.assertEqual(ep.handle(m2), m3); self.assertEqual(len(ep.ops), n)
        m4 = sf.handle(m3); self.assertEqual(sf.handle(m3), m4)
        ep.handle(m4); self.assertIsNone(ep.handle(m4))
        self.assertEqual(sum(t["event"] == "handshake_accepted" for t in sf.sim.trace), 1)

    def test_m1_ciphertext_modified(self):
        ep, sf = self.pair(); f = unpack(ep.begin()); f[-1] = f[-1][:-1]+bytes([f[-1][-1]^1])
        with self.assertRaises(ValueError): sf.handle(pack(*f))
        self.assertIsNone(sf.sim.sf.root)

    def test_m2_modified(self):
        ep, sf = self.pair(); f = unpack(sf.handle(ep.begin())); f[-1] = f[-1][:-1]+bytes([f[-1][-1]^1])
        with self.assertRaises(ValueError): ep.handle(pack(*f))
        self.assertIsNone(ep.sim.endpoint.root)

    def test_m3_wrong_confirmation(self):
        ep, sf = self.pair(); f = unpack(ep.handle(sf.handle(ep.begin()))); f[-1] = bytes(32)
        with self.assertRaises(ValueError): sf.handle(pack(*f))

    def test_m4_wrong_confirmation(self):
        ep, sf = self.pair(); f = unpack(sf.handle(ep.handle(sf.handle(ep.begin())))); f[-1] = bytes(32)
        with self.assertRaises(ValueError): ep.handle(pack(*f))

    def test_policy_change_during_handshake_aborts_sf(self):
        ep, sf = self.pair(); m3 = ep.handle(sf.handle(ep.begin())); sf.sim.authority["slice-A"] = [1,"p1",False]
        with self.assertRaises(ValueError): sf.handle(m3)
        self.assertIsNone(sf.sim.sf.root)

    def test_revoked_slice_excluded_from_grant(self):
        ep, sf = self.pair(); sf.sim.authority["slice-A"][2] = True; self.complete(ep, sf)
        self.assertEqual(set(ep.sim.endpoint.slices), {"slice-B"})

    def test_wrong_pinned_signing_key_rejected(self):
        ep, sf = self.pair()
        sf.peer_verifier = sf.signer.public_key()
        with self.assertRaises(ValueError): sf.handle(ep.begin())

    def test_wrong_profile_rejected(self):
        ep, _ = self.pair("P1"); _, sf = self.pair("P2")
        with self.assertRaises(ValueError): sf.handle(ep.begin())

    def test_old_m2_cannot_complete_new_run(self):
        ep, sf = self.pair(); old = sf.handle(ep.begin()); ep.begin()
        with self.assertRaises(ValueError): ep.handle(old)

    def test_parser_padding_and_hkdf(self):
        with self.assertRaises(ValueError): unpack(b"\0\0\0\x05xx")
        with self.assertRaises(ValueError): unpad(pad(b"x",16)[:-1]+b"\x01",16)
        with self.assertRaises(ValueError): pad(b"x"*16,16)
        key, info = bytes(range(32)), b"known-context"
        self.assertEqual(expand(key,info), HKDFExpand(algorithm=hashes.SHA256(),length=32,info=info).derive(key))

    def test_socket_real_handshake_and_lifecycle(self):
        run = DistributedRun("sbake",0,credentials=self.temp.name)
        try:
            run.establish(); run.act({"tick":1,"op":"change"})
            run.act({"tick":2,"op":"deliver","kind":"UPD"});run.act({"tick":3,"op":"deliver","kind":"ACK"})
            run.act({"tick":4,"op":"service"})
            self.assertEqual(run.result()["service_accepted"],1)
            self.assertEqual(run.result()["accepted_root_fixtures"],0)
        finally: run.close()

    def test_lost_handshake_responses_use_cached_retries(self):
        for kind in ("M2", "M4"):
            run = DistributedRun("sbake",0,credentials=self.temp.name)
            try:
                run.establish(drop_once=kind); self.assertEqual(run.handshake_measurements[0]["retries"],1)
                self.assertEqual(len(run.crypto_operations),9)
            finally: run.close()

    def test_process_restart_reloads_credentials_and_rekeys(self):
        run = DistributedRun("sbake",0,credentials=self.temp.name)
        try:
            run.establish(); run.restart("endpoint"); run.act({"tick":1,"op":"service"})
            run.establish(); run.act({"tick":2,"op":"service"})
            self.assertEqual(run.result()["service_accepted"],1)
            self.assertEqual(run.result()["completed_handshakes"],2)
        finally: run.close()

    def test_byte_accounting_survives_process_restart(self):
        from run_pq_experiments import lifecycle_bytes
        for role in ("endpoint","sf"):
            run = DistributedRun("sbake",0,credentials=self.temp.name)
            try:
                run.establish();run.call("sf","change",slice="slice-A");run.deliver("UPD","slice-A")
                before = lifecycle_bytes(run);run.restart(role)
                self.assertEqual(lifecycle_bytes(run),before)
            finally:run.close()

    def test_mlkem768_backend_interoperability(self):
        from pqcrypto.kem import ml_kem_768
        from cryptography.hazmat.primitives.asymmetric.mlkem import MLKEM768PrivateKey, MLKEM768PublicKey
        pk, sk = ml_kem_768.generate_keypair()
        secret, ct = MLKEM768PublicKey.from_public_bytes(pk).encapsulate()
        self.assertEqual(ml_kem_768.decrypt(sk, ct),secret)
        private = MLKEM768PrivateKey.generate()
        ct, secret = ml_kem_768.encrypt(private.public_key().public_bytes_raw())
        self.assertEqual(private.decapsulate(ct),secret)

    def test_modified_concealment_kem_ciphertext_rejected(self):
        ep, sf = self.pair(); f = unpack(ep.begin()); ct = bytearray(f[1]);ct[0] ^= 1;f[1] = bytes(ct)
        with self.assertRaises(ValueError):sf.handle(pack(*f))
        self.assertIsNone(sf.sim.sf.root)

    def test_duplicate_handshake_does_not_reset_traffic_replay_guard(self):
        run = DistributedRun("sbake",0,credentials=self.temp.name)
        try:
            m1=run.call("endpoint","handshake_begin")
            m2=run.call("sf","handshake_receive",raw=m1)
            m3=run.call("endpoint","handshake_receive",raw=m2)
            m4=run.call("sf","handshake_receive",raw=m3)
            run.call("endpoint","handshake_receive",raw=m4)
            raw=run.call("endpoint","probe",slice="slice-A",request_id=1)
            self.assertTrue(run.call("sf","service",slice="slice-A",raw=raw))
            run.call("sf","handshake_receive",raw=m3)
            self.assertFalse(run.call("sf","service",slice="slice-A",raw=raw))
        finally:run.close()

    def test_malformed_late_confirmation_keeps_accepted_root(self):
        ep,sf=self.pair(); messages=self.complete(ep,sf)
        for peer,wire in ((sf,messages[2]),(ep,messages[3])):
            root=(peer.sim.sf if peer.role=="sf" else peer.sim.endpoint).root
            fields=unpack(wire);fields[-1]=bytes(32)
            with self.assertRaises(ValueError):peer.handle(pack(*fields))
            self.assertEqual((peer.sim.sf if peer.role=="sf" else peer.sim.endpoint).root,root)
            self.assertEqual(peer.phase,"ACCEPTED")


if __name__ == "__main__": unittest.main()
