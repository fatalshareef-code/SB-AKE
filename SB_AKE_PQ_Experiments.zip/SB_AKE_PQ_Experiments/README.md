# Real stored-credential ML-KEM/ML-DSA handshake and recovery measurements

## Run on Ubuntu/WSL

Extract `SB_AKE_PQ_Handshake_Experiments.zip` into a **new directory**. Open a terminal in that directory, where `run_pq_experiments.py` is located:

```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
python3 -m unittest -v test_lifecycle.py test_distributed.py test_pq_handshake.py
python3 run_pq_experiments.py --profiles P1 P2 --trials 30 --seeds 5 --out my_pq_results
```

The script provisions fresh lab credentials, launches both workers automatically, runs real handshakes, measures costs, and closes its workers. Credentials live in a temporary directory and are deleted when the suite finishes. They are not included in the archive. Do not run older `run_distributed.py` commands when you intend to test the real handshake: that older runner deliberately retains fixture mode.

For a short smoke run:

```bash
python3 run_pq_experiments.py --profiles P1 --trials 3 --seeds 1 --out pq_smoke
```

For the same run with an added 10 ms forwarding hold per handshake or lifecycle packet:

```bash
python3 run_pq_experiments.py --profiles P1 P2 --trials 30 --seeds 5 --wall-delay-ms 10 --out pq_results_10ms
```

Python 3.10+ is required. Dependencies are pinned: cryptography 50.0.2 and pqcrypto 0.4.0. The ML-DSA backend must support the specified parameter sets; no classical or simulated fallback is provided. `pqcrypto` supplies ML-KEM-512 and ML-KEM-768; cryptography/OpenSSL supplies ML-DSA-44 and ML-DSA-65 with the `SB-AKE-v3` signature context. No liboqs build is required.

## What changed

In real-handshake mode the controller **cannot provision root fixtures**. Endpoint and SF derive their root independently from the ephemeral session KEM secret. The controller transfers M1–M4 bytes through loopback TCP. It does not receive either peer's root, ephemeral private key, KEM shared secret or confirmation key.

Offline trusted provisioning supplies each worker's own persistent signing credential and pinned public peer keys. SF additionally holds its static concealment decapsulation key. Credential files have mode 0600. The signing credential is serialized as a seed and loaded into a retained signing-key object once per worker start; it is not regenerated on every handshake. File permissions are a lab safeguard, not a secure-element or capture-resistance claim. All processes run under the same OS user; separate address spaces are not an access-control boundary against that user.

Workers use the four-message stored-key concealed profile. This is the manuscript's **no-PUF/stored-identity variant**, not a PUF implementation. Both candidates with guarded lifecycle rules use the same real handshake and the same compiled primitive backends, allowing comparison of lifecycle behavior without attributing random timing differences to candidate labels.

## Mapping to manuscript equations

`pq_handshake.py` uses 32-bit-length-prefixed fields, fixed-size inner slot arrays and outer padding. `P` pins the wire encoding, parameter profile, network/SF identifiers, static-key hashes, capacity and padding sizes. Hashes and signatures use the exact wire bytes.

| Equations / mechanism | Executed implementation |
|---|---|
| (10) | Fresh endpoint ML-KEM ephemeral pair per new run |
| (11)–(13) | Static-network concealment encapsulation; HKDF-Extract/Expand request key |
| (14)–(18) | Padded request, ML-DSA endpoint signature, AES-256-GCM M1 |
| (19)–(25) | Current authorized grant, ephemeral-session encapsulation, SF signature, encrypted M2 |
| (26)–(29) | Endpoint session decapsulation; exact-wire transcript hash; HKDF root and confirmation key |
| (30)–(32) | Context-bound slice base; stable update key; ACK key derived from update key and transcript |
| (33)–(35) | Endpoint and SF HMAC confirmation; local acceptance only after corresponding validation |
| Traffic export | Second HKDF expansion from slice base, binding profile/transcript/context/direction/purpose |

P1 uses ML-KEM-512/ML-DSA-44; P2 uses ML-KEM-768/ML-DSA-65. The request/grant capacity is two slices, with a 512-byte canonical inner array. Outer signed payload padding is 4,096 bytes in P1 and 6,144 bytes in P2. These are an **experimental pinned profile**, not a previously specified binary interoperability standard or minimum-size encoding. Invalid lengths, duplicate fields/slices, malformed padding, wrong profiles, failed signatures/AEAD, stale response transcripts and wrong confirmation tags are rejected.

The update/ACK envelope remains the previous canonical JSON lifecycle wire profile, but `PQPeer` now derives its management and traffic keys using the manuscript's two-stage hierarchy. Synthetic application probes use MACs, not a complete application AEAD profile. Admission control, enrollment manifests, physical PUF acquisition, autonomous timers, full root expiry, multiple concurrently live accepted roots and general concurrent-session state are not implemented.

## Retry and restart semantics

M1, M2, M3 and M4 retries use cached exact bytes. A lost M2 causes the endpoint to resend M1 and receive the cached M2; a lost M4 causes cached M3/M4 retransmission. The loss-control microbenchmarks prescribe one immediate retry: **no timeout wait is included**.

SF rechecks granted policy/epoch/revocation before accepting M3. A policy change during the handshake aborts that pending exchange. Late malformed handshake messages do not erase an already accepted root; repeated accepted confirmations do not reset the traffic replay guard. Transient KEM and confirmation references are dropped after acceptance or abort. This is logical deletion, not guaranteed physical zeroization in Python or native allocations.

Endpoint/SF restart kills and replaces the process, reloads its stored long-term credential, and leaves session roots absent. Only public authority records are restored to SF. A new real handshake then restores the matching association. Worker creation and credential loading are excluded from handshake-only latency and included in the scripted restart-to-service recovery observation.

## Measurements

- `handshake_summary.csv`: observed mean, median, sample SD and linearly interpolated p95 across 30 fresh-root handshakes per profile. One is the first association and the rest replace it, using the same already running workers and credentials.
- `handshake_costs.csv`: every measured handshake, including initial association, later reauthorization in lifecycle schedules and lost-M2/M4 controls.
- `crypto_operations_P*.json`: per-operation durations for the dedicated handshake benchmark. There are nine timed asymmetric operations per successful ordinary exchange.
- `lifecycle_runs.csv`: 13 matched scenarios, five fixture-independent **schedule seeds**, three candidates and two profiles: 390 executions. Twelve schedules are deterministic; only randomized loss/duplication varies the network decisions.
- `recovery_costs.csv`: time from a selected fault injection to the first subsequent successful slice-A service probe. In a guarded candidate this follows proper activation. A minimal diagnostic candidate may accept before its exact ACK; those rows must not be interpreted as secure recovery.
- `run_metadata.json`, `schedules.json`, `process_identity.json`, and seed-zero traces record the environment and reproduction workload.
- `pq_tests.log`: combined executed regression tests.

Handshake latency is measured on the parent's monotonic clock from endpoint begin to endpoint acceptance. It includes five local RPC calls, actual wire transport through the trusted relay, serialization and host scheduling. It excludes worker startup, credential provisioning/loading, enrollment and external policy-service lookup. Aggregate worker-handler time and measured asymmetric-operation time are separate subsets of this elapsed time; **do not add them together**.

`protocol_bytes_sent` counts binary M1–M4 bytes, including retransmissions in the loss controls. It excludes base64 control wrapping, TCP/IP headers, credential provisioning and application traffic. The actual ordinary exchanges are 10,820 bytes (P1) and 15,940 bytes (P2), including pinned padding and framing. These differ from the manuscript's analytical lower bounds; neither represents radio energy or the full network-layer cost.

Recovery timing includes the intervening scripted RPCs/probes and, for restart scenarios, OS process restart and credential loading. It excludes real autonomous timeout/backoff waits because those actions are externally scheduled. Incremental lifecycle bytes count sender-offered update/ACK messages after injection; handshake bytes are reported separately. Injected duplicate copies, control transport framing and service probes are excluded. Recoveries with no successful slice-A probe are recorded as `restored=False` without inventing a duration.

These are measurements of software running on the recorded host, not ESP32-C6, radio, power or memory measurements. They are not directly comparable to published embedded primitive timings. Timing values and randomized transcripts will change on reproduction. The schedule hashes and expected guarded safety metrics should reproduce. Semantic trace comparison removes transcript/ciphertext hashes and PIDs, since each real handshake uses fresh randomness.

## Evidence and next scope

This stage adds executable integration and host measurements. It does not complete G1/G2 computational reductions, full-state symbolic verification, side-channel protection, constant-time parser analysis or PUF feasibility. The optional identity backend remains unvalidated. Sharing the same handshake and guarded engine across candidates is a consistency experiment; it does not show a unique efficiency gain over an equally guarded generic hierarchy.

Official backend documentation:

- https://cryptography.io/en/50.0.2/hazmat/primitives/asymmetric/mldsa/
- https://cryptography.io/en/50.0.2/hazmat/primitives/asymmetric/mlkem/
- https://github.com/backbone-hq/pqcrypto

Sources and results are provided for review. Do not deploy this lab control channel as a production authenticated service.
